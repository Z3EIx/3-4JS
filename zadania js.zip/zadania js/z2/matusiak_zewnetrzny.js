document.write("ostatnia modyfikacja strony".fontcolor("#008080").strike().bold().fontsize(7)+"<br>"); 
document.write(document.lastModified .strike().fontcolor("#008080").fontsize(7)); 